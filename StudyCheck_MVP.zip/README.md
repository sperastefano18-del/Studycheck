# StudyCheck MVP

Prototipo front-end del sito di studio descritto nella conversazione.

## Cosa funziona già
- Dashboard e materie personalizzabili
- Identità visiva per materia
- Creazione di nuove materie
- Inserimento di appunti
- Modalità interrogazione simulata
- Risultato con lacuna individuata
- Appunti con evidenziazione della lacuna
- Ripasso mirato
- Storico/progressi
- Lavagna digitale disegnabile

## Cosa manca per una versione reale
Il prototipo non contiene ancora un modello AI/backend reale. Per trasformarlo in prodotto servono:
- OCR per foto di appunti
- speech-to-text per dettatura e risposte vocali
- backend/database per salvare utenti, appunti e progressi
- modello AI per generare domande, valutare risposte e collegarle agli appunti
- analisi dei disegni
- autenticazione e gestione privacy

Apri `index.html` in un browser per provare il prototipo.
